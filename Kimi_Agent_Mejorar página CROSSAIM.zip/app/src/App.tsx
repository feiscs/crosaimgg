import { useEffect, useState, useRef } from 'react';
import { 
  ShoppingCart, 
  Star, 
  ExternalLink, 
  Gamepad2, 
  Monitor, 
  Headphones, 
  Mic, 
  Keyboard, 
  Mouse,
  ChevronRight,
  Sparkles,
  Zap,
  Trophy,
  TrendingUp,
  Shield,
  Truck
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface Product {
  id: number;
  name: string;
  category: string;
  specs: string;
  price: string;
  originalPrice: string;
  discount: string;
  rating: string;
  reviews: string;
  image: string;
  link: string;
  featured?: boolean;
  icon: React.ReactNode;
}

const products: Product[] = [
  {
    id: 1,
    name: "Logitech G Pro X Superlight",
    category: "Mouse Gaming #1 Best Seller",
    specs: "63g | Hero 25K | Wireless | 70h",
    price: "127,99 €",
    originalPrice: "159,99 €",
    discount: "-20%",
    rating: "4.7",
    reviews: "28,432",
    image: "https://us.maxgaming.com/bilder/artiklar/zoom/28011_3.jpg",
    link: "https://amzn.eu/d/0bzFFKQC",
    featured: true,
    icon: <Mouse className="w-5 h-5" />
  },
  {
    id: 2,
    name: "Razer DeathAdder V3 Pro",
    category: "Mouse Alternativo Pro",
    specs: "63g | Focus Pro 30K | 90h",
    price: "143,99 €",
    originalPrice: "159,99 €",
    discount: "-10%",
    rating: "4.6",
    reviews: "12,847",
    image: "https://i.rtings.com/assets/products/XZTWfCaG/razer-deathadder-v3-pro/design-medium.jpg",
    link: "https://amzn.eu/d/0c21M5um",
    icon: <Mouse className="w-5 h-5" />
  },
  {
    id: 3,
    name: "SteelSeries QcK Heavy XXL",
    category: "Mousepad Gaming",
    specs: "900x400x6mm | Control | Antideslizante",
    price: "19,99 €",
    originalPrice: "29,99 €",
    discount: "-33%",
    rating: "4.8",
    reviews: "45,231",
    image: "https://images.ctfassets.net/hmm5mo4qf4mf/4ztePfpJr7ceJsquHlLTdp/8a111d18e09513ef2cf2139b16be7d52/1200x_buy_qck-heavy_xxl_03-fix.png",
    link: "https://amzn.eu/d/0d5EnHu8",
    icon: <Gamepad2 className="w-5 h-5" />
  },
  {
    id: 4,
    name: "BenQ Zowie XL2546K 24.5\"",
    category: "Monitor Esports 240Hz",
    specs: "240Hz | 0.5ms | DyAc+ | TN",
    price: "429,00 €",
    originalPrice: "499,00 €",
    discount: "-14%",
    rating: "4.7",
    reviews: "3,421",
    image: "https://image.benq.com/is/image/benqco/XL2546K_04-1",
    link: "https://amzn.eu/d/01y98PwN",
    icon: <Monitor className="w-5 h-5" />
  },
  {
    id: 5,
    name: "HyperX Cloud II Wireless",
    category: "Auriculares Gaming",
    specs: "Wireless | 7.1 | 30h | PC/PS",
    price: "111,99 €",
    originalPrice: "149,99 €",
    discount: "-25%",
    rating: "4.5",
    reviews: "89,432",
    image: "https://i.rtings.com/assets/products/zIPPnEOh/hyperx-cloud-2-cloud-ii-wireless/design-medium.jpg",
    link: "https://amzn.eu/d/02AjYssJ",
    icon: <Headphones className="w-5 h-5" />
  },
  {
    id: 6,
    name: "FIFINE XLR USB",
    category: "Micrófono Streaming",
    specs: "XLR/USB | Dinámico | Podcast",
    price: "79,99 €",
    originalPrice: "99,99 €",
    discount: "-20%",
    rating: "4.6",
    reviews: "8,234",
    image: "https://fifinemicrophone.com/cdn/shop/files/FIFINE-K688-dynamic-microphone-black.png",
    link: "https://amzn.eu/d/01c38KHS",
    icon: <Mic className="w-5 h-5" />
  },
  {
    id: 7,
    name: "CORSAIR K70 PRO TKL RGB",
    category: "Teclado Mecánico RGB",
    specs: "TKL | OPX Optical | 8KHz | RGB",
    price: "129,99 €",
    originalPrice: "169,99 €",
    discount: "-24%",
    rating: "4.7",
    reviews: "11,432",
    image: "https://assets.corsair.com/image/upload/c_pad,q_auto,h_1024,w_1024,f_auto/products/Gaming-Keyboards/CH-9109410-NA/Gallery/K70_RGB_PRO_PBT_01.webp",
    link: "https://amzn.eu/d/04jOwQ85",
    icon: <Keyboard className="w-5 h-5" />
  },
  {
    id: 8,
    name: "Elgato Stream Deck MK.2 White",
    category: "Control Streaming",
    specs: "15 LCD Keys | USB-C | Blanco",
    price: "127,49 €",
    originalPrice: "149,99 €",
    discount: "-15%",
    rating: "4.8",
    reviews: "22,567",
    image: "https://res.cloudinary.com/elgato-pwa/image/upload/q_auto,f_auto/f_auto/q_auto:best/v1747489190/Products/10GBA9911/above-the-fold/NEW/SD-White-ATF-05-Mobile.jpg",
    link: "https://amzn.eu/d/03XiPZmI",
    icon: <Sparkles className="w-5 h-5" />
  }
];

const stats = [
  { value: "8", label: "Productos", icon: <ShoppingCart className="w-5 h-5" /> },
  { value: "4.7", label: "Valoración Media", icon: <Star className="w-5 h-5" /> },
  { value: "222K+", label: "Reseñas", icon: <TrendingUp className="w-5 h-5" /> },
  { value: "Prime", label: "Envío Gratis", icon: <Truck className="w-5 h-5" /> }
];

function App() {
  const [isVisible, setIsVisible] = useState<Set<number>>(new Set());
  const [scrollY, setScrollY] = useState(0);
  const productRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const id = Number(entry.target.getAttribute('data-id'));
          if (entry.isIntersecting) {
            setIsVisible((prev) => new Set([...prev, id]));
          }
        });
      },
      { threshold: 0.1, rootMargin: '50px' }
    );

    productRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white overflow-x-hidden">
      {/* Background Effects */}
      <div className="fixed inset-0 grid-pattern opacity-50 pointer-events-none" />
      
      {/* Animated gradient orbs */}
      <div 
        className="fixed top-0 left-1/4 w-[600px] h-[600px] rounded-full opacity-20 pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(255,42,42,0.4) 0%, transparent 70%)',
          transform: `translateY(${scrollY * 0.3}px)`,
          filter: 'blur(80px)'
        }}
      />
      <div 
        className="fixed bottom-0 right-1/4 w-[500px] h-[500px] rounded-full opacity-15 pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(255,153,0,0.3) 0%, transparent 70%)',
          transform: `translateY(${-scrollY * 0.2}px)`,
          filter: 'blur(80px)'
        }}
      />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500 to-red-700 flex items-center justify-center">
                <CrosshairIcon className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold tracking-tight">
                CROSS<span className="text-red-500">AIM</span>
              </span>
            </div>
            <div className="hidden md:flex items-center gap-6">
              <span className="text-sm text-gray-400">Setup Gaming Profesional</span>
              <Badge variant="outline" className="border-red-500/50 text-red-400">
                <Zap className="w-3 h-3 mr-1" /> Amazon.es
              </Badge>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-500/10 border border-red-500/30 mb-8 animate-fade-in">
              <Trophy className="w-4 h-4 text-red-500" />
              <span className="text-sm font-medium text-red-400">Setup Verificado para Gaming Competitivo</span>
            </div>

            {/* Title */}
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 animate-slide-up">
              <span className="gradient-text">CROSSAIM</span>
              <br />
              <span className="text-white">Setup Gaming</span>
            </h1>

            {/* Subtitle */}
            <p className="text-lg sm:text-xl text-gray-400 max-w-2xl mx-auto mb-10 animate-slide-up stagger-1">
              Los mejores productos gaming seleccionados para competir al máximo nivel. 
              Todos los enlaces son de <span className="text-[#ff9900] font-semibold">Amazon España</span> con envío Prime.
            </p>

            {/* Affiliate Badge */}
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-2xl bg-white/5 border border-white/10 mb-12 animate-slide-up stagger-2">
              <Shield className="w-5 h-5 text-green-500" />
              <span className="text-gray-400">Afiliado:</span>
              <code className="px-3 py-1 rounded-lg bg-red-500/20 text-red-400 font-mono font-bold">
                feisks1-21
              </code>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto animate-slide-up stagger-3">
              {stats.map((stat, index) => (
                <div 
                  key={index}
                  className="glass rounded-2xl p-4 text-center hover:bg-white/10 transition-colors"
                >
                  <div className="flex justify-center mb-2 text-red-500">{stat.icon}</div>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-xs text-gray-500">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Productos <span className="text-red-500">Destacados</span>
            </h2>
            <p className="text-gray-400 max-w-xl mx-auto">
              Equipamiento profesional seleccionado para maximizar tu rendimiento en cada partida
            </p>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product, index) => (
              <div
                key={product.id}
                ref={(el) => { productRefs.current[index] = el; }}
                data-id={product.id}
                className={`group relative ${
                  isVisible.has(product.id) ? 'animate-scale-in' : 'opacity-0'
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className={`relative h-full rounded-3xl overflow-hidden bg-gradient-to-b from-white/10 to-white/5 border border-white/10 product-card-hover ${
                  product.featured ? 'ring-2 ring-red-500 ring-offset-2 ring-offset-[#0a0a0a]' : ''
                }`}>
                  
                  {/* Featured Badge */}
                  {product.featured && (
                    <div className="absolute top-4 right-4 z-10">
                      <Badge className="bg-red-500 text-white border-0">
                        <Star className="w-3 h-3 mr-1 fill-current" /> TOP
                      </Badge>
                    </div>
                  )}

                  {/* Discount Badge */}
                  <div className="absolute top-4 left-4 z-10">
                    <Badge className="bg-green-500 text-white border-0 font-bold">
                      {product.discount}
                    </Badge>
                  </div>

                  {/* Image Container */}
                  <div className="relative h-48 bg-white/5 flex items-center justify-center p-6 overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/20" />
                    <img
                      src={product.image}
                      alt={product.name}
                      className="relative z-10 max-h-full max-w-full object-contain transition-transform duration-500 group-hover:scale-110"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = 'https://via.placeholder.com/300x200?text=Producto';
                      }}
                    />
                  </div>

                  {/* Content */}
                  <div className="p-5">
                    {/* Category */}
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-red-500">{product.icon}</span>
                      <span className="text-xs font-medium text-red-400 uppercase tracking-wider">
                        {product.category}
                      </span>
                    </div>

                    {/* Name */}
                    <h3 className="font-bold text-lg mb-2 line-clamp-2 group-hover:text-red-400 transition-colors">
                      {product.name}
                    </h3>

                    {/* Rating */}
                    <div className="flex items-center gap-2 mb-3">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-[#ff9900] fill-[#ff9900]" />
                        <span className="font-semibold">{product.rating}</span>
                      </div>
                      <span className="text-gray-500 text-sm">({product.reviews})</span>
                    </div>

                    {/* Specs */}
                    <div className="px-3 py-2 rounded-lg bg-black/30 mb-4">
                      <p className="text-xs text-gray-400 font-mono">{product.specs}</p>
                    </div>

                    {/* Price */}
                    <div className="flex items-center gap-3 mb-4">
                      <span className="text-2xl font-bold">{product.price}</span>
                      <span className="text-gray-500 line-through text-sm">{product.originalPrice}</span>
                    </div>

                    {/* CTA Button */}
                    <a
                      href={product.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl btn-amazon text-black font-bold text-sm transition-all"
                    >
                      <ShoppingCart className="w-4 h-4" />
                      Comprar en Amazon.es
                      <ExternalLink className="w-3 h-3" />
                    </a>
                    <p className="text-center text-xs text-gray-500 mt-2">
                      Enlace afiliado • Envío Prime
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="glass rounded-3xl p-8 md:p-12">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-red-500/20 flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold mb-2">Productos Verificados</h3>
                <p className="text-gray-400 text-sm">Todos los productos han sido probados y seleccionados para gaming competitivo</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-[#ff9900]/20 flex items-center justify-center mx-auto mb-4">
                  <Truck className="w-8 h-8 text-[#ff9900]" />
                </div>
                <h3 className="text-xl font-bold mb-2">Envío Prime</h3>
                <p className="text-gray-400 text-sm">Envío gratuito y rápido en toda la península con Amazon Prime</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-green-500/20 flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-8 h-8 text-green-500" />
                </div>
                <h3 className="text-xl font-bold mb-2">Mejores Precios</h3>
                <p className="text-gray-400 text-sm">Descuentos actualizados diariamente en Amazon España</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative py-16 px-4 sm:px-6 lg:px-8 border-t border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-500 to-red-700 flex items-center justify-center">
                <CrosshairIcon className="w-7 h-7 text-white" />
              </div>
              <div>
                <span className="text-2xl font-bold">CROSS<span className="text-red-500">AIM</span></span>
                <p className="text-xs text-gray-500">Setup Profesional para Valorant</p>
              </div>
            </div>

            {/* Affiliate Info */}
            <div className="text-center">
              <p className="text-gray-400 text-sm mb-2">Afiliado Amazon.es</p>
              <code className="px-4 py-2 rounded-lg bg-red-500/20 text-red-400 font-mono font-bold">
                feisks1-21
              </code>
            </div>

            {/* Amazon Badge */}
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#ff9900] text-black font-bold">
              <span>amazon.es</span>
              <ChevronRight className="w-4 h-4" />
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-white/5 text-center">
            <p className="text-gray-500 text-sm">
              Todos los enlaces dirigen a Amazon España • Envío Prime disponible en toda la península
            </p>
            <p className="text-gray-600 text-xs mt-2">
              © 2025 CROSSAIM. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Custom Crosshair Icon
function CrosshairIcon({ className }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="2" x2="12" y2="6" />
      <line x1="12" y1="18" x2="12" y2="22" />
      <line x1="2" y1="12" x2="6" y2="12" />
      <line x1="18" y1="12" x2="22" y2="12" />
      <circle cx="12" cy="12" r="2" fill="currentColor" />
    </svg>
  );
}

export default App;
